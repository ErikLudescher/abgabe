import React, { useEffect, useState, useRef } from 'react';
import { Client } from '@stomp/stompjs';
import Movement from './movement';
import RenderingMap from './MapRendering';

const WS_URL = 'ws://localhost:8080/gs-guide-backendAmongUs';

function App() {
  const [connected, setConnected] = useState(false);
  const [mapData, setMapData] = useState([]); // State to hold the map data
  const clientRef = useRef(null); // Use useRef to persist the client instance

  useEffect(() => {
    const client = new Client({
      brokerURL: WS_URL,
      reconnectDelay: 5000,
      debug: (str) => {
        console.log(str);
      },
    });

    client.onConnect = () => {
      console.log('Connected to WebSocket server');
      setConnected(true);
      // Subscribe to the topic where the map data is sent
      client.subscribe('/topic/map', (message) => {
        console.log('Received map:', message.body);
        const map = JSON.parse(message.body); // Parse the JSON message
        setMapData(map); // Update the mapData state with the new map
      });
    };

    client.onStompError = (error) => {
      console.error('STOMP Error:', error);
    };

    client.onWebSocketError = (error) => {
      console.error('WebSocket Error:', error);
    };

    // Activate the client
    client.activate();
    clientRef.current = client; // Store the client instance in the useRef hook

    // Clean up function to deactivate the client on component unmount
    return () => {
      console.log('Disconnecting WebSocket client');
      client.deactivate();
    };
  }, []);

  const handleClick = (key: String) => {
    const client = clientRef.current; // Access the client from the ref
    if (client && connected) {
      client.publish({
        destination: '/app/move',
        body: JSON.stringify({ name: key }),
      });
      console.log('Sent movement update to server:', key);
    }
  };

  return (
    <div>
      <p>{connected ? 'Connected to WebSocket server!' : 'Connecting...'}</p>
      <RenderingMap mapData={mapData} />
      <Movement handleClick={handleClick} />
    </div>
  );
}

export default App;
