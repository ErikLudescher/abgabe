import React from 'react';


function RenderingMap({mapData}){

    return (
        <div>
          {mapData.map((row, i) => (
            <div key={i}>
              {row.map((cell, j) => (
                <span key={j}>{cell} </span>
              ))}
            </div>
          ))}
        </div>
      );
    
}

export default RenderingMap;

