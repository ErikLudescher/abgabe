import React, { useEffect } from 'react';
let number = 0  
function Movement({ handleClick }) {


  useEffect(() => { 
    const detectkeydown = (e) => {
      if (e.key === "w") {
        handleClick(e.key);
      }
      else if (e.key === "a") {
        handleClick(e.key);
      }
      else if (e.key === "s") {
        handleClick(e.key);
      }
      else if (e.key === "d") {
        handleClick(e.key);
      }
    };

    window.addEventListener("keydown", detectkeydown, true);
    return () => window.removeEventListener("keydown", detectkeydown, true);
  }, [handleClick]);

  return null; 
}

export default Movement;