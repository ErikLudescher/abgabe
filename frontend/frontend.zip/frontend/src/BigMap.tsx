import React, { useEffect } from 'react';

function BigMap({ show, onClose, playerPosition, tasks, allCoords }) {
  const originalWidth = 1024;
  const originalHeight = 1024;
  const zoomFactor = 0.62;
  const tileSize = 32; // Each tile is 32 pixels
  console.log("my player", playerPosition);
  if (!show) return null;

  console.log("All coordinates:");
  allCoords.forEach((coord, index) => {
    console.log(`Coord ${index}: x=${coord.x}, y=${coord.y}`);
  });

  // Event listener for ESC key
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.keyCode === 27) { // 27 is the keyCode for Escape key
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  return (
    <div style={{
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: `${originalWidth * zoomFactor}px`,
      height: `${originalHeight * zoomFactor}px`,
      border: '2px solid white',
      borderRadius: '10px',
      zIndex: 9000,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      overflow: 'hidden',
      backgroundColor: 'black'
    }}>
      <div style={{
        width: '100%',
        height: '100%',
        position: 'relative',
        borderRadius: '10px',
        overflow: 'hidden'
      }}>
        <img
          src="https://i.imgur.com/VaVUXX9.png"
          alt="Big Map"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover'
          }}
        />
        {tasks.map((task, index) => (
          <div
            key={index}
            style={{
              position: 'absolute',
              top: `${task.coordinates.y * tileSize * zoomFactor}px`,
              left: `${task.coordinates.x * tileSize * zoomFactor}px`,
              color: 'yellow',
              fontSize: '15px',
              fontWeight: 'bold',
              transform: 'translate(-50%, -50%)',
              zIndex: 9001
            }}
          >
            {task.description}
          </div>
        ))}
        <div
          style={{
            position: 'absolute',
            top: `${playerPosition.y * zoomFactor}px`,
            left: `${playerPosition.x * zoomFactor}px`,
            color: 'red',
            fontSize: '20px',
            fontWeight: 'bold',
            transform: 'translate(-50%, -50%)',
            zIndex: 200000 // Ensure player marker is on top
          }}
        >
          O
        </div>
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '10px',
            right: '10px',
            backgroundColor: 'red',
            border: 'none',
            borderRadius: '5px',
            padding: '5px 10px',
            cursor: 'pointer',
            zIndex: 10000,
          }}
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default BigMap;
